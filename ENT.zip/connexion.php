
<?php

$db = new PDO('mysql:host=sql212.infinityfree.com;dbname=if0_35562184_ent;port=3306;charset=utf8', 'if0_35562184', '042yTSbxoK7kw'); 
 

?>




 