-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Янв 11 2024 г., 14:21
-- Версия сервера: 10.6.16-MariaDB
-- Версия PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `iarovaia_ent`
--

-- --------------------------------------------------------

--
-- Структура таблицы `absence`
--

CREATE TABLE `absence` (
  `id_abs` int(10) NOT NULL,
  `ext_etudiant` int(10) NOT NULL,
  `ext_cours` int(10) NOT NULL,
  `abs_duree` int(6) NOT NULL,
  `abs_justificatif` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `absence`
--

INSERT INTO `absence` (`id_abs`, `ext_etudiant`, `ext_cours`, `abs_duree`, `abs_justificatif`) VALUES
(1, 1, 1, 4, 'pas de rer');

-- --------------------------------------------------------

--
-- Структура таблицы `actualite`
--

CREATE TABLE `actualite` (
  `id_actu` int(11) NOT NULL,
  `actu_text` varchar(8000) NOT NULL,
  `actu_date` date NOT NULL,
  `actu_titre` varchar(300) NOT NULL,
  `actu_img` varchar(500) DEFAULT NULL,
  `actu_accroche` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `actualite`
--

INSERT INTO `actualite` (`id_actu`, `actu_text`, `actu_date`, `actu_titre`, `actu_img`, `actu_accroche`) VALUES
(1, 'Le Center for World University Rankings (CWUR) a publié le 15 mai 2023 son classement des 20 000 meilleurs établissements d’enseignement supérieur du monde pour l’édition 2023. L’Université Gustave Eiffel se positionne à la 597e place après avoir occupé la 660e position en 2022 et la 802e position en 2021, ce qui correspond au top 3 %des meilleures universités dans le monde. \n Elle progresse également du côté des établissements français en passant de la 28e position après avoir occupé la 29e position en 2022 et la 35e position en 2021. <br>\nCe classement est basé sur plusieurs indicateurs regroupés en quatre domaines :\n\nl’éducation, fondée sur la réussite académique des étudiants ;\nl’employabilité, basée sur la réussite professionnelle des anciens élèves ;\nle corps professoral, mesuré par le nombre de distinctions académiques prestigieuses ;\nla performance de la recherche, avec de grands critères comme les résultats de la recherche, la qualité des publications, le nombre de citations ou encore la mesure de l’influence.', '2023-12-05', 'Classement Center for World University Rankings (CWUR) 2023', 'classement.jpeg', 'Le Center for World University Rankings (CWUR) a publié le 15 mai 2023 son classement des 20 000 meilleurs établissements d’enseignement supérieur du monde pour l’édition 2023. L’Université Gustave Eiffel se positionne à la 597e place après avoir occupé la 660e position en 2022 et la 802e position en 2021, ce qui correspond au top 3 %des meilleures universités dans le monde. Elle progresse également du côté des établissements français en passant de la 28e position après avoir occupé la 29e position en 2022 et la 35e position en 2021.'),
(2, 'Le 1er juin 2023, le Parlement Étudiant et la Vice-Présidence Étudiante de l’Université Gustave Eiffel s\'associent pour organiser la deuxième édition de la Pride Universitaire. Nouveau format et nouvelles activités, retrouvez le programme détaillé de cette journée qui s\'annonce haute en couleurs. <br> <br>\n\nLe jeudi 1er juin 2023, la Pride universitaire fera son grand retour à l\'Université Gustave Eiffel. Pour cette seconde édition, le Parlement Étudiant et la Vice-Présidence Étudiante de l\'établissement ont mutualisé leurs forces pour proposer un événement d\'une ampleur différente à celle de l\'année précédente. <br>\n\nÀ cette occasion, plusieurs services et associations de l\'université se greffent au mouvement en proposant des activtés tout au long de la journée : <br>\n \n\nLe SSU (Service de Santé Universitaire) proposera un stand pour déconstruire les stéréotypes d’IST et plus généralement dans le monde médical envers la communauté LGBTQIA+\n <br>\nLa mission égalité s’associera au service juridique pour pouvoir proposer des points sur les droits administratifs dont disposent les étudiant·e·s au sein de l’université (changement de nom par exemple)\n <br>\nUne fresque des fiertés avec la mission art et culture ainsi qu’une invitation à la discussion sur la place de l’art dans la communauté LGBTQIA+.\nUne manifestation placée sous le signe de la fête\n <br>\n\nEn écho aux marches des fiertés organisées en juin dans de nombreux pays pour sensibiliser aux violences faites contre les personnes LGBTQIA+, une déambulation aura lieu sur le campus et sera suivie de plusieurs temps de divertissement comme des concerts, un drag show ou des prestations de danses.\n<br>\nLes participants auront également accès à des structures gonflables, des stands de maquillage et un photocall.\n\nPour que cette journée se déroule au mieux, les organisateurs ont mis un point d\'honneur à offrir une parfaite sécurité aux participants : la déambulation sera encadrée par la police de Noisiel etplusieurs agents de sécurité seront présent tout au long de la manifestation.', '2023-12-03', 'Pride universitaire 2023 : l\'université aux couleurs de la communauté LGBTQIA+', 'pride.jpg', 'Le 1er juin 2023, le Parlement Étudiant et la Vice-Présidence Étudiante de l’Université Gustave Eiffel s\'associent pour organiser la deuxième édition de la Pride Universitaire. Nouveau format et nouvelles activités, retrouvez le programme détaillé de cette journée qui s\'annonce haute en couleurs.'),
(3, 'Les étudiants en Master Management de l’innovation – Immobilier professionnel (MASTER MIPI) – Numérique (MASTER MITIC) annoncent la tenue de l’événement annuel « UNIVCAMP » pour sa 12ème édition, le 20 avril 2023. Comme chaque année, les innovations numériques et immobilières sont mises à l’honneur dans une logique d’open innovation. <br>\nConstruit par les étudiants de l\'Université Gustave Eiffel, UNIVCAMP est destiné aux professionnels, enseignants et chercheurs, ainsi qu\'à toute personne intéressée par la ville de demain, les propositions de services réalistes et responsables, ainsi que les talents qui les incarnent. <br>\n\nCet évènement dont le fil rouge est l\'urbanité, a pour objectif de pousser au partage de connaissances. Ainsi,d l\'occasion de questionner les rapports créés ou consolidés par les nouveaux services dans l’écosystème d’un territoire, d’une ville, d’un quartier, d’un ensemble de bâtiments. Repris sous le terme d’urbanité, les finalités des services imaginés par la promotion 2023 propose une urbanité plus responsable, un avenir plus durable et plus équitable : partager pour plus d’inclusion et de sobriété et construire de nouveaux échanges professionnels. <br>\n\n \n\nUn évènement placé sous le signe de l\'échange\nTout au long de l\'évènement, venez découvrir 10 projets de services innovants réalisés à partir du besoin de partenaires, pitchés en plénière, discutés par un conseil académique et professionnel. C’est la possibilité en atelier d’interagir avec les équipes et les invités autour de démonstrations et de prototypes, de réseauter et pourquoi pas y recruter des talents ! <br>\n\nParmi ces partenaires, nous retrouvons : BNP Paribas Real Estate Property, Bouygues Energies & Services, Eurodisney Real Estate Development, Keolis, Pluri\'elle, Paypal, Syndicat Professionnel Numeum, Ville de Noisy-le-Grand, Ville de Magny-le-Hongre, Ville de Trilport . <br>\n\nÀ la fin de la matinée, les projets sont primés en fonction des productions en collaboration avec des experts du domaine : innovation de service, vidéo, compétences d’innovation, pitch, start-up...', '2023-12-05', 'UNIVCAMP : « S’unir pour grandir, c’est construire l’avenir »', 'unir.png', 'Les étudiants en Master Management de l’innovation – Immobilier professionnel (MASTER MIPI) – Numérique (MASTER MITIC) annoncent la tenue de l’événement annuel « UNIVCAMP » pour sa 12ème édition, le 20 avril 2023. Comme chaque année, les innovations numériques et immobilières sont mises à l’honneur dans une logique d’open innovation.'),
(4, 'Depuis son lancement il y a quelques mois, l’IA conversationnel ChatGPT suscite la polémique, en particulier dans le monde universitaire où elle est parfois considérée comme un outil de triche. Enseignant-chercheur à ESIEE Paris, l’école d’ingénieurs de l’Université Gustave Eiffel, Daniel Courivaud livre son point de vue en tant que professeur et informaticien. <br>\nEn tant qu’enseignant-chercheur en informatique, quel regard portez-vous sur ChatGPT ? <br>\nDaniel Courivaud : L’outil va, à très court terme, avoir un impact très important dans le monde de l’informatique et de son enseignement. Il y a de nombreux domaines scientifiques où ChatGPT n’est pas du tout efficace : en physique ou en électronique par exemple il va être totalement contreproductif et écrire des bêtises énormes avec une assurance trompeuse. Mais ce n’est pas le cas de l’informatique, qui est un langage pas si éloigné du langage naturel pour lequel ChatGPT est si performant. Pour produire du code, ChatGPT n’est pas parfait mais extrêmement fort : il a appris avec des codes réalisés par des experts. On peut faire un parallèle avec la révolution industrielle de la fin du XIXe siècle. Les machines de l’époque ont remplacé pour un coût dérisoire la capacité de l\'humain à fournir un travail physique. Nous nous retrouvons 150 ans plus tard à pouvoir remplacer - toujours à faible coût - la capacité de l\'humain à fournir un travail intellectuel. Cela annonce des bouleversements sociétaux de même ampleur, voire plus importants.\n \n\n \n \n\n \nUtilisez-vous ChatGPT en cours et si oui comment ?\nD.C. : Je l’ai immédiatement utilisé dans mes enseignements. ChatGPT est à la fois un outil de production et un outil d’assistance. En tant qu’assistant, il a une valeur ajoutée très intéressante. On peut très bien lui demander d’améliorer la robustesse du code afin qu’il résiste mieux aux erreurs de l\'utilisateur. On peut également lui demander de documenter un code, c’est-à-dire écrire en langage naturel ce que fait le code pour mieux le comprendre. C’est une tache fastidieuse et peu intéressante que ChatGPT fait mieux que nous. C’est un vrai gain de temps. En revanche, utiliser ChatGPT comme outil de production peut être problématique, en particulier pour des étudiants pour lesquels la formation de l’esprit logique ne serait plus assurée pleinement.', '2023-12-05', 'ChatGPT dans l’enseignement supérieur : « La vraie question n’est pas son interdiction mais son usag', 'chatgpt.png', 'Depuis son lancement il y a quelques mois, l’IA conversationnel ChatGPT suscite la polémique, en particulier dans le monde universitaire où elle est parfois considérée comme un outil de triche. Enseignant-chercheur à ESIEE Paris, l’école d’ingénieurs de l’Université Gustave Eiffel, Daniel Courivaud livre son point de vue en tant que professeur et informaticien.'),
(5, 'La Nuit de l’Info est une compétition nationale qui réunit étudiant·es, enseignant·es et entreprises pour travailler ensemble sur le développement d’une application web.\r\n\r\nLa Nuit se déroule tous les ans, du premier jeudi du mois de décembre, coucher du soleil, jusqu\'au lever du soleil le lendemain matin.\r\n\r\nLes participants ont la durée d\'une nuit pour proposer, implémenter et packager une application Web 2.0. ', '2023-12-07', 'Nuit de l\'info !', 'nuitinfo.png', 'Les participants ont la durée d\'une nuit pour proposer, implémenter et packager une application Web 2.0. ');

-- --------------------------------------------------------

--
-- Структура таблицы `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `categorie_titre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `categorie_titre`) VALUES
(1, 'art'),
(2, 'politique et societe'),
(3, 'technologie'),
(4, 'MMI'),
(5, 'INFO'),
(6, 'Marketing et communication'),
(7, 'emploi et stage\r\n'),
(8, 'université'),
(9, 'événement');

-- --------------------------------------------------------

--
-- Структура таблицы `categorie_actu`
--

CREATE TABLE `categorie_actu` (
  `ext_categorie` int(11) NOT NULL,
  `ext_actu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `categorie_actu`
--

INSERT INTO `categorie_actu` (`ext_categorie`, `ext_actu`) VALUES
(2, 2),
(9, 2),
(8, 1),
(9, 3),
(3, 4),
(4, 4),
(5, 4),
(4, 5),
(9, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `cours`
--

CREATE TABLE `cours` (
  `id_cours` int(11) NOT NULL,
  `cours_temps_debut` datetime NOT NULL,
  `cours_temps_fin` datetime NOT NULL,
  `cours_salle` varchar(50) NOT NULL,
  `ext_matiere` int(11) NOT NULL,
  `groupe` varchar(5) NOT NULL,
  `exam` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `cours`
--

INSERT INTO `cours` (`id_cours`, `cours_temps_debut`, `cours_temps_fin`, `cours_salle`, `ext_matiere`, `groupe`, `exam`) VALUES
(1, '2024-01-08 08:00:00', '2024-01-08 12:30:00', '1', 1, 'M', 1),
(3, '2024-01-10 13:45:00', '1900-01-10 17:45:00', '78', 1, 'CD', 1),
(8, '2024-01-15 12:00:00', '2024-01-15 14:00:00', '34', 1, 'C', 1),
(9, '2024-01-07 15:30:00', '2024-01-07 17:00:00', '5', 3, 'CD', 1),
(10, '2024-01-12 08:15:00', '2024-01-11 10:15:00', '123', 3, 'M', NULL),
(11, '2024-01-11 10:30:00', '2024-01-11 12:30:00', '126', 4, 'M', NULL),
(12, '2024-01-11 13:30:00', '2024-01-11 15:30:00', '156', 5, 'M', NULL),
(13, '2024-01-12 10:30:00', '2024-01-12 12:30:00', '126', 1, 'M', NULL),
(14, '2024-01-11 13:30:00', '2024-01-11 15:30:00', '156', 6, 'M', NULL),
(15, '2024-01-12 13:30:00', '2024-01-12 15:30:00', '121', 7, 'M', NULL),
(16, '2024-01-12 15:45:00', '2024-01-12 17:45:00', '122', 6, 'M', NULL),
(17, '2024-01-09 08:15:00', '2024-01-09 10:15:00', '126', 2, 'M', NULL),
(18, '2024-01-09 10:30:00', '2024-01-09 12:30:00', '123', 7, 'M', NULL),
(19, '2024-01-09 15:45:00', '2024-01-09 17:45:00', '126', 6, 'M', NULL),
(20, '2024-01-09 13:30:00', '2024-01-09 15:30:00', '123', 7, 'M', NULL),
(21, '2024-01-11 10:30:00', '2024-01-11 12:30:00', '121', 6, 'M', NULL),
(22, '2024-01-11 13:30:00', '2024-01-11 15:30:00', '156', 2, 'CD', NULL),
(23, '2024-01-11 15:45:00', '2024-01-11 17:45:00', '122', 1, 'M', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `creneau`
--

CREATE TABLE `creneau` (
  `id_creneau` int(11) NOT NULL,
  `horaire` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `creneau`
--

INSERT INTO `creneau` (`id_creneau`, `horaire`) VALUES
(1, '8h15 - 10h15'),
(2, '10h30 - 12h30'),
(3, '13h30 - 15h30'),
(4, '15h45 - 17h45');

-- --------------------------------------------------------

--
-- Структура таблицы `document`
--

CREATE TABLE `document` (
  `id_doc` int(11) NOT NULL,
  `ext_user` int(11) NOT NULL,
  `doc_titre` varchar(100) NOT NULL,
  `doc_url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `eval_exam`
--

CREATE TABLE `eval_exam` (
  `id_eval_exam` int(11) NOT NULL,
  `coefficient` int(11) NOT NULL,
  `ext_cours` int(11) NOT NULL,
  `title_exam` varchar(250) NOT NULL,
  `description_exam` text NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `eval_exam`
--

INSERT INTO `eval_exam` (`id_eval_exam`, `coefficient`, `ext_cours`, `title_exam`, `description_exam`, `type`) VALUES
(1, 10, 7, 'Partiel de Maketing', 'Sur la méthode POEM et les différentes politiques.', 1),
(2, 2, 2, 'Partiel de développement Web', 'Frameworks, API, et résolution de problèmes complexes liés à la création d\'applications web dynamiques.', 1),
(3, 3, 3, 'Design Graphique et Création Numérique', 'Exercices pratiques axés sur la conception d\'images, de logos et d\'éléments visuels pour des médias numériques.', 1),
(4, 2, 1, 'Gestion de Projet', 'Évaluez la compréhension des concepts de gestion de projet dans le contexte du marketing digital, en mettant l\'accent sur la planification, l\'exécution et la mesure des campagnes.', 1),
(5, 2, 1, 'Animation 3D', 'Création d\'une séquence animée, évaluant la manipulation de logiciels et la qualité artistique.', 1),
(6, 1, 7, 'Réseaux Sociaux et Stratégie de Marque', 'Utilisation stratégique des médias sociaux pour la promotion de la marque.', 1),
(7, 1, 7, 'Sécurité des Applications Web', 'Concevoir des solutions pour protéger les applications web contre les vulnérabilités.', 1),
(8, 3, 8, 'Photographie Numérique et Retouche', 'Photographie et post-production. Présentation d\'un portefeuille de photos retouchées.', 1),
(9, 0, 2, 'Rédaction de Contenu Marketing', 'Contenu marketing persuasif : rédaction d\'articles, de publicités et de copies pour différentes plateformes.', 1),
(10, 1, 3, 'Stratégie de Commerce Électronique', 'plan complet : conception du site, gestion des stocks et stratégies de marketing.', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `eval_projet`
--

CREATE TABLE `eval_projet` (
  `id_eval_projet` int(11) NOT NULL,
  `ext_matiere` int(11) NOT NULL,
  `eval_date_debut` datetime(6) NOT NULL,
  `eval_date_fin` datetime(6) NOT NULL,
  `coefficient` int(11) NOT NULL,
  `title_projet` varchar(500) NOT NULL,
  `description_projet` text DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT 2,
  `consignes_projet` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `eval_projet`
--

INSERT INTO `eval_projet` (`id_eval_projet`, `ext_matiere`, `eval_date_debut`, `eval_date_fin`, `coefficient`, `title_projet`, `description_projet`, `type`, `consignes_projet`) VALUES
(1, 2, '2024-02-16 05:41:02.000000', '2023-11-14 14:41:19.000000', 1, 'Plateforme de Développement Web Collaboratif', 'Créez une plateforme en ligne où les développeurs web peuvent collaborer sur des projets, partager des ressources et résoudre des problèmes en temps réel. Intégrez des outils de gestion de code, de suivi des problèmes et de discussion pour faciliter la collaboration.', 2, NULL),
(2, 4, '2024-01-01 16:52:53.000000', '2024-01-16 16:52:53.000000', 1, 'Studio de Design Virtuel en 3D', 'Concevez un studio virtuel en 3D permettant aux designers de créer, collaborer et présenter leurs projets en temps réel. Intégrez des outils de modélisation, de rendu et de partage pour faciliter la création et la visualisation de designs.', 2, NULL),
(3, 5, '2024-01-09 22:10:37.000000', '2024-01-31 23:13:00.000000', 7, 'Application de Création Numérique Collaborative', 'Développez une application collaborative où les artistes numériques peuvent créer ensemble en temps réel, partager des idées, et bénéficier d\'outils avancés tels que la réalité virtuelle pour une expérience immersive de création.', 2, NULL),
(4, 6, '2024-01-09 22:21:06.000000', '2024-01-31 23:13:00.000000', 7, 'Plateforme de Streaming Éducatif en Marketing Digital', 'Créez une plateforme de streaming dédiée à l\'éducation en marketing digital. Offrez des cours en direct, des ateliers interactifs et des ressources pour aider les professionnels à rester à jour sur les dernières tendances et techniques de marketing', 2, NULL),
(5, 5, '2024-01-09 22:21:27.000000', '2024-01-28 22:21:00.000000', 2, 'Campagne Publicitaire Multimédia pour une Marque de Mode', 'Concevez une campagne publicitaire complète, incluant la création d\'affiches, de vidéos promotionnelles et la mise en œuvre d\'une stratégie de marketing en ligne pour promouvoir une nouvelle collection de vêtements', 2, NULL),
(6, 5, '2024-01-09 22:23:16.000000', '2024-01-28 22:21:00.000000', 2, 'Création d\'une Série de Vidéos Éducatives sur le Développement Web', 'Produisez une série de vidéos éducatives axées sur le développement web, couvrant des sujets allant des bases du codage aux technologies avancées. Intégrez des éléments visuels captivants pour faciliter la compréhension.', 2, NULL),
(7, 6, '2024-01-09 22:49:29.000000', '2024-01-27 22:53:00.000000', 3, 'Analyse Multimédia de Campagnes Publicitaires sur les Réseaux Sociaux', 'Effectuez une analyse approfondie des campagnes publicitaires sur les réseaux sociaux, en utilisant des graphiques, des vidéos et des rapports visuels pour présenter des données marketing importantes, telles que l\'engagement, la conversion et le retour sur investissement.', 2, NULL),
(8, 1, '2024-01-09 22:50:56.000000', '2024-01-27 22:53:00.000000', 3, 'Projet de Design d\'Expérience Utilisateur (UX) pour une Application Mobile', 'Concevez une expérience utilisateur exceptionnelle pour une application mobile, en se concentrant sur la création d\'interfaces conviviales, d\'animations intuitives et d\'éléments visuels engageants pour améliorer l\'interaction utilisateur.', 2, NULL),
(9, 7, '2024-01-09 23:00:29.000000', '2024-01-12 22:57:00.000000', 4, 'Studio de Création de Contenu Éducatif en Ligne', 'Établissez un studio en ligne où les créateurs de contenu peuvent produire du matériel éducatif interactif, tels que des cours en ligne, des tutoriels et des démonstrations, pour divers domaines d\'apprentissage.', 2, NULL),
(10, 2, '2024-01-09 23:19:48.000000', '2024-01-12 23:08:00.000000', 2, 'Création d\'un ENT', 'Avec une interface moderne et intuitive, le projet vise à simplifier la gestion éducative, offrant des outils de planification, d\'évaluation et de personnalisation pour les écoles. La sécurité des données est une priorité, assurant la protection des informations sensibles tout en offrant une expérience éducative optimale.', 2, NULL),
(11, 1, '2024-01-09 23:20:41.000000', '2024-01-12 23:08:00.000000', 2, 'Portfolio', 'Développez un portfolio professionnel percutant pour mettre en valeur vos compétences, projets et réalisations. L\'accent sera mis sur une présentation visuelle attrayante et une organisation intuitive pour captiver les employeurs et clients potentiels.', 2, NULL),
(12, 2, '2024-01-09 23:39:59.000000', '2024-01-05 23:35:00.000000', 1, 'Blog', 'Entraînez-vous à coder en créant un mini_blog !', 2, NULL),
(13, 6, '2024-01-09 23:41:56.000000', '2024-01-12 23:41:00.000000', 2, 'Cv vidéo', 'Réalise, produit et fait le montage de ta propre vidéo. ', 2, NULL),
(14, 7, '2024-01-09 23:42:55.000000', '2024-02-01 23:42:00.000000', 2, 'Résaweb', 'Développe un site de réservation.', 2, NULL),
(15, 7, '2024-01-09 23:46:00.000000', '2024-01-26 23:45:00.000000', 3, 'Création d\'une Exposition d\'Art Numérique Interactive', 'Concevez une exposition d\'art numérique interactive, utilisant des projections, des installations interactives et des éléments audiovisuels pour offrir une expérience immersive aux visiteurs et explorer les intersections entre l\'art et la technologie.', 2, NULL),
(16, 6, '2024-01-09 23:47:27.000000', '2024-01-09 23:47:00.000000', 3, 'Élaboration d\'une Stratégie de Contenu Visuel pour les Réseaux Sociaux', 'Développez une stratégie de contenu visuel complète pour les médias sociaux, incluant des images, des vidéos et des infographies, afin de renforcer la présence en ligne d\'une entreprise et d\'engager le public.', 2, 'Certificat_de_Scolaritй_3BMMD2_2023-2024_DARIA_IAROVAIA.pdf'),
(17, 6, '2024-01-10 00:12:21.000000', '2024-01-05 00:12:00.000000', 2, 'Campagne de Marketing Digital pour une Nouvelle Application Mobile :', 'Concevez et exécutez une campagne de marketing digital complète pour lancer une nouvelle application mobile. Cette stratégie intégrera des tactiques telles que la publicité sur les médias sociaux, le marketing d\'influence, le référencement (SEO) et des campagnes par e-mail afin de maximiser la visibilité, d\'attirer les utilisateurs cibles et de favoriser les téléchargements.', 2, ''),
(18, 1, '2024-01-10 00:17:59.000000', '2024-01-05 00:12:00.000000', 2, 'Projet d\'Intégration Web pour un Site de Commerce Électronique', 'Développez l\'intégration web complète d\'un site de commerce électronique, en mettant l\'accent sur une interface utilisateur conviviale et une navigation intuitive', 2, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `fastaccess`
--

CREATE TABLE `fastaccess` (
  `id_fast` int(11) NOT NULL,
  `name_fast` varchar(150) NOT NULL,
  `link_fast` varchar(150) NOT NULL,
  `img_fast` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `fastaccess`
--

INSERT INTO `fastaccess` (`id_fast`, `name_fast`, `link_fast`, `img_fast`) VALUES
(1, 'cPanel', '\'https://cpanel.\' <?= $SESSION[nom_user] ?> \'.butmmi.o2switch.site/\'', 'cpanel.png'),
(2, 'Canva', 'https://www.canva.com/learn/students/', 'canva.svg'),
(3, 'Creative Cloud', 'https://www.adobe.com/creativecloud/buy/students.html', 'creativecloud.svg'),
(4, 'Figma', 'https://www.figma.com/education/', 'figma.svg'),
(5, 'File Sender', 'https://filesender.renater.fr/', 'filesender.svg'),
(6, 'GitHub', 'https://education.github.com/pack', 'github.svg'),
(7, 'Media Coder', 'https://www.mediacoderhq.com/', 'mediacoder.svg'),
(8, 'Miro', 'https://miro.com/', 'miro.svg'),
(9, 'Notion', 'https://www.notion.so/', 'notion.svg'),
(10, 'Zoom', 'https://www.zoom.com/', 'zoom.svg');

-- --------------------------------------------------------

--
-- Структура таблицы `info_matiere`
--

CREATE TABLE `info_matiere` (
  `id_info` int(11) NOT NULL,
  `information` varchar(100) NOT NULL,
  `info_date` date NOT NULL,
  `info_titre` varchar(100) NOT NULL,
  `ext_matiere` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `info_matiere`
--

INSERT INTO `info_matiere` (`id_info`, `information`, `info_date`, `info_titre`, `ext_matiere`) VALUES
(1, 'On va faire plein de choses utiles et interessante. C\'est formidable', '2023-12-06', 'Cours du 06/12', 1),
(2, 'Pleins de belles infos sur la matière !', '2023-12-04', 'Cours de CSS', 3),
(3, 'Plein de code javascript, de json et de github pour toujours plus de fun !', '2023-12-05', 'Tous les secrets de Javascript', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `mail`
--

CREATE TABLE `mail` (
  `id_mail` int(11) NOT NULL,
  `mail_text` varchar(1000) NOT NULL,
  `mail_document` varchar(100) NOT NULL,
  `mail_date` date NOT NULL,
  `mail_objet` varchar(100) NOT NULL,
  `ext_utilisateur` int(50) NOT NULL,
  `ext_destinataire` int(50) NOT NULL,
  `ext_status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `mail`
--

INSERT INTO `mail` (`id_mail`, `mail_text`, `mail_document`, `mail_date`, `mail_objet`, `ext_utilisateur`, `ext_destinataire`, `ext_status`) VALUES
(1, 'La mission Arts et Culture a le plaisir de vous convier à la représentation exceptionnelle de la pièce de théâtre :\r\nScrooge !\r\n\r\n \r\nUn soir de Noël, visité par un fantôme et une ribambelle d’Esprits, Scrooge va découvrir qu’une vie consacrée à l’argent engendre peu de profits. De son enfance à ses vieux jours, tout défile pour le mettre face à son destin et ses responsabilités. Pour jouer de cette métamorphose, une comédienne et la vingtaine de personnages qu’elle incarne surgissent avec masques, poupées, objets et marionnettes.\r\n\r\nCette aventure à rebondissements de Charles Dickens est drôle et édifiante, littéraire et populaire, fantastique et philosophique.\r\nLe Mercredi 13 Décembre 2023 à 18:00\r\nMaison de l\'étudiant - Foyer du BDE\r\nRue des frères lumière, 77420, Champs sur Marne\r\n\r\nEntrée gratuite - événement ouvert à tous - spectacle tout public\r\n\r\nINSCRIPTION OBLIGATOIRE ICI.\r\n\r\nLa représentation sera suivie, pour celles et ceux qui le souhaitent,\r\nd\'un temps d\'échange avec les a', '', '0000-00-00', '[PIÈCE DE THÉÂTRE] - Scrooge - 13 Décembre 2023 à 18:00', 1, 3, 1),
(2, 'Bonjour à tous,\r\n\r\nNous avons le plaisir de vous annoncer notre candidature pour l\'élection du conseil administratif qui se tiendra la semaine prochaine (du 4 au 8 décembre).\r\n\r\nNous nous engageons solennellement à défendre les intérêts des étudiants, à travers :\r\n\r\n    La préservation de l’excellence académique, en s’opposant à l’utilisation de l’écriture inclusive, en défendant une université bilingue par la promotion de programmes d’échanges internationaux, en rendant gratuites à tout moment de l’année les sessions de certification Voltaire.\r\n\r\n\r\n    Le développement de la commodité du campus, en élargissant les horaires du CROUS et de la bibliothèque, en modernisant les bâtiments (prises, wifi, chauffage) et en mettant en place des navettes pour les résidences éloignées du campus.\r\n\r\n\r\n    La protection de l’environnement, en installant un véritable système de tri sélectif, plus de cendriers et de poubelles, et en améliorant l’isolation des bâtiments pour réduire la consommation én', '', '0000-00-00', ' Présentation de la liste TPGE', 2, 6, 1),
(3, 'Bonjour, \r\nJe serai absente le 6 et 7 décembre, \r\ncoordialement, \r\nNéroli ', '', '0000-00-00', 'Absences', 1, 3, 3),
(4, 'Bonjour à tous, \r\nVoici les notes de votre TP test. \r\nBonne journée ', '', '0000-00-00', 'Notes JS', 4, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `materiel`
--

CREATE TABLE `materiel` (
  `id_materiel` int(11) NOT NULL,
  `materiel_titre` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `type` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `notice` varchar(100) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `materiel`
--

INSERT INTO `materiel` (`id_materiel`, `materiel_titre`, `description`, `type`, `image`, `notice`, `stock`) VALUES
(1, 'Osmo mobile 6', 'Osmo Mobile 6 est un stabilisateur intelligent pour smartphone doté de nombreuses fonctionnalités créatives.', 'camera', '<img class=\"img_mat0\" src=\"./img/materiel/osmo.png\" alt=\"\">', 'notice_osmo.pdf', 14),
(2, 'Micro-cravate', 'Parfait pour des enregistrements audio discrets et de bonne qualité.', 'son', '<img class=\"img_mat\" src=\"./img/materiel/micro_cravate.png\" alt=\"\">', NULL, 5),
(3, 'Caméra interview', 'Caméra compacte avec capteur et objectif zoom. Idéal pour vos interviews ! ', 'camera', '<img class=\"img_mat\" src=\"./img/materiel/camera.png\" alt=\"\">', NULL, 6),
(4, 'Lampe à LED', 'Une lampe puissante qui crée l\'ambiance parfaite pour vos tournages !', 'lumiere', '<img class=\"img_mat\" src=\"./img/materiel/lampe_led.png\" alt=\"\">', NULL, 0),
(5, 'Micro Canon', 'Micro compact et directionnel, idéal pour des enregistrements audio nets et précis.', 'son', '<img class=\"img_mat\" src=\"./img/materiel/micro_canon.png\" alt=\"\">', NULL, 8),
(6, 'Projecteur', 'Illuminez avec précision en ajustant la zone d\'éclairage stratégiquement.  ', 'lumiere', '<img class=\"img_mat\" src=\"./img/materiel/projecteur.png\" alt=\"\">', NULL, 8),
(7, 'Trépied', 'Idéal pour des plans fixes afin de stabiliser l\'image. ', 'camera', '<img class=\"img_mat\" src=\"./img/materiel/trepied.png\" alt=\"\">', NULL, 7);

-- --------------------------------------------------------

--
-- Структура таблицы `matiere`
--

CREATE TABLE `matiere` (
  `id_matiere` int(11) NOT NULL,
  `programme` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `couleur` varchar(100) NOT NULL,
  `nom_matiere` varchar(100) NOT NULL,
  `ext_prof` varchar(100) NOT NULL,
  `coef_matiere` int(11) NOT NULL,
  `ext_contenu` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `matiere`
--

INSERT INTO `matiere` (`id_matiere`, `programme`, `description`, `couleur`, `nom_matiere`, `ext_prof`, `coef_matiere`, `ext_contenu`) VALUES
(1, 'MMI1', 'Rendre beau et accessible, c\'est important !', '#FFBDBD', '	\nIntégration web', '3', 2, 1),
(2, 'MMI1', 'Cours de PHP pour apprendre à mieux coder', '#D1F4FF', 'PHP', '8', 1, 2),
(3, 'MMI2', '??', '#DAFFCD', 'Intégration', '3', 11, 3),
(4, 'MMI2', '', '#D4CDFF', 'JavaScript', '4', 2, NULL),
(5, 'MMI2', '', '#FEFFCD', 'Communication', '6', 1, NULL),
(6, 'MMI1', 'Apprendre à bien communiquer et à réfléchir à un bon marketing pour votre future entreprise !', '#FFCDE8', 'Marketing', '6', 2, NULL),
(7, 'MMI1', 'Vous apprendrez du javascript, oui, mais aussi du github et des modèles de base de données !', '#D4CDFF', 'JavaScript', '4', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `note_exam`
--

CREATE TABLE `note_exam` (
  `ext_etudiant` int(11) NOT NULL,
  `ext_eval_exam` int(11) NOT NULL,
  `note_exam` int(11) NOT NULL,
  `commentaire_exam` text DEFAULT NULL,
  `id_note` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `note_exam`
--

INSERT INTO `note_exam` (`ext_etudiant`, `ext_eval_exam`, `note_exam`, `commentaire_exam`, `id_note`) VALUES
(1, 3, 1, 'Il y a une marge de progression certaine !', 1),
(2, 3, 10, 'La moyenne, on voit que c\'est compris', 2),
(3, 3, 33, 'Bravo !', 5),
(5, 3, 12, 'Bon travail', 6),
(4, 4, 3, '', 7);

-- --------------------------------------------------------

--
-- Структура таблицы `note_projet`
--

CREATE TABLE `note_projet` (
  `ext_projet` int(11) NOT NULL,
  `ext_etudiant` int(11) NOT NULL,
  `note_projet` int(11) NOT NULL,
  `commentaire_projet` text DEFAULT NULL,
  `id_note_projet` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `note_projet`
--

INSERT INTO `note_projet` (`ext_projet`, `ext_etudiant`, `note_projet`, `commentaire_projet`, `id_note_projet`) VALUES
(1, 1, 66, 'BRAVOOOOOOOOOOO', 1),
(2, 2, 3, NULL, 2),
(1, 2, 1, 'Pas terrible, mais mieux que rien', 3),
(1, 5, 12, 'C\'est très bien !', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `notification`
--

CREATE TABLE `notification` (
  `id_notif` int(11) NOT NULL,
  `ext_user` int(11) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `reservation`
--

CREATE TABLE `reservation` (
  `id_reservation` int(11) NOT NULL,
  `res_date_debut` datetime DEFAULT NULL,
  `res_date_fin` datetime DEFAULT NULL,
  `ext_salle` varchar(50) DEFAULT NULL,
  `ext_materiel` int(50) DEFAULT NULL,
  `ext_utilisateur` int(50) DEFAULT NULL,
  `ext_creneau` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `reservation`
--

INSERT INTO `reservation` (`id_reservation`, `res_date_debut`, `res_date_fin`, `ext_salle`, `ext_materiel`, `ext_utilisateur`, `ext_creneau`) VALUES
(1, '2023-12-04 08:15:00', '2023-12-04 10:15:00', '201', 0, 2, 1),
(2, '2023-12-04 15:45:00', '2023-12-04 17:45:00', '157', 0, 1, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `role_titre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `role`
--

INSERT INTO `role` (`id_role`, `role_titre`) VALUES
(1, 'Étudiant'),
(2, 'Professeur'),
(3, 'Admin');

-- --------------------------------------------------------

--
-- Структура таблицы `salle`
--

CREATE TABLE `salle` (
  `id_salle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `salle`
--

INSERT INTO `salle` (`id_salle`) VALUES
(121),
(122),
(123),
(126),
(156),
(157),
(201);

-- --------------------------------------------------------

--
-- Структура таблицы `status_mail`
--

CREATE TABLE `status_mail` (
  `id_status` int(11) NOT NULL,
  `status_nom` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `status_mail`
--

INSERT INTO `status_mail` (`id_status`, `status_nom`) VALUES
(1, 'envoyé'),
(2, 'pas envoyé'),
(3, 'brouillon');

-- --------------------------------------------------------

--
-- Структура таблицы `todo_list`
--

CREATE TABLE `todo_list` (
  `id_todo_list` int(11) NOT NULL,
  `todo_list_text` varchar(100) NOT NULL,
  `todo_list_status` tinyint(1) DEFAULT NULL,
  `ext_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `todo_list`
--

INSERT INTO `todo_list` (`id_todo_list`, `todo_list_text`, `todo_list_status`, `ext_user`) VALUES
(1, 'Faire tout l\'ENT', 0, 2),
(2, 'Créer une base de donnée', 1, 2),
(3, 'Finir le semestre', 0, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `user_login` varchar(100) NOT NULL,
  `user_nom` varchar(100) NOT NULL,
  `user_prenom` varchar(100) NOT NULL,
  `user_mdp` varchar(150) NOT NULL,
  `user_photo` varchar(100) DEFAULT NULL,
  `user_theme` int(11) DEFAULT NULL,
  `ext_role` int(11) DEFAULT NULL,
  `user_programme` varchar(100) DEFAULT NULL,
  `user_groupe` varchar(100) DEFAULT NULL,
  `user_acces_rapide1` int(2) NOT NULL DEFAULT 0,
  `user_acces_rapide2` int(2) NOT NULL DEFAULT 0,
  `user_acces_rapide3` int(2) NOT NULL DEFAULT 0,
  `user_acces_rapide4` int(2) NOT NULL DEFAULT 0,
  `ext_todo_list` int(11) DEFAULT NULL,
  `formation` varchar(100) DEFAULT NULL,
  `user_retard` int(100) NOT NULL DEFAULT 0,
  `user_naissance` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id_user`, `user_login`, `user_nom`, `user_prenom`, `user_mdp`, `user_photo`, `user_theme`, `ext_role`, `user_programme`, `user_groupe`, `user_acces_rapide1`, `user_acces_rapide2`, `user_acces_rapide3`, `user_acces_rapide4`, `ext_todo_list`, `formation`, `user_retard`, `user_naissance`) VALUES
(1, 'neroli.prak', 'Prak', 'Neroli', '$2y$10$ROMGd06r3Q9PWg3gWPm0uO8dhOp5pxjZ2bvu9.qpSQfabi9GbOfd2', 'neroli-prak.jpeg', 1, 1, 'MMI1', 'D', 2, 3, 0, 0, NULL, 'MMI', 0, '2004-04-13'),
(2, 'solene.jeannin', 'Jeannin', 'Solene', '$2y$10$D4X9IZDPthB4vtEoVpfSu.MlHT3eNdvektH8lj9cFuzcen1/m0ud.', 'solene-jeannin.jpeg', 0, 1, 'MMI2', 'C', 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00'),
(3, 'gaelle.charpentier', 'Charpentier', 'Gaelle', '$2y$10$tRf6tx7rY2lqVJZC1K.weOBFaTX7VEkFSZSni5/zNYR6db8XYMfke', 'gaelle-charpentier.jpeg', 0, 2, 'MMI', NULL, 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00'),
(4, 'philippe.gambette', 'Gambette', 'Philippe', '$2y$10$0.1tXAScrysgX2EQMmFeVO/9tsWUZ41K69T4d4rbd6utXtlQFhHNy', 'philippe-gambette.jpeg', 0, 2, 'MMI', NULL, 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00'),
(5, 'sophie.david', 'David', 'Sophie', '$2y$10$mLu.8TRUwZAN4xvKP5Iif.V03UK0CX67zRuiRks6d.i8GH3LhQSD6', 'sophie-david.jpeg', 0, 3, NULL, NULL, 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00'),
(6, 'leyla.jaoued', 'Jaoued', 'Leyla', '$2y$10$.vOaunDNpwvmAz9pNwf.euRcXWwxyHURNucbmkLsBq2Gwx9/T3A0u', 'leyla-jaoued.jpeg', 0, 2, NULL, NULL, 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00'),
(7, 'andrea.laizeau', 'Laizeau', 'Andrea', '$2y$10$vTBp.9BOepRmugOaot6OlOyvkP0y8sad279oJP0aU4tmwEIXr6Pla', 'andrea-laizeau.jpeg', 0, 1, 'MMI1', 'C', 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00'),
(8, 'renaud.eppstein', 'Eppstein', 'Renaud', '$2y$10$GLBZWrk99REdHpyhMhHRROhNOjsTEvarzs1o2RN7e4F1ytpwvVvbK', 'renaud-eppstein.jpeg', NULL, 2, 'MMI1', NULL, 0, 0, 0, 0, NULL, 'MMI', 0, '0000-00-00');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `absence`
--
ALTER TABLE `absence`
  ADD PRIMARY KEY (`id_abs`);

--
-- Индексы таблицы `actualite`
--
ALTER TABLE `actualite`
  ADD PRIMARY KEY (`id_actu`);

--
-- Индексы таблицы `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Индексы таблицы `cours`
--
ALTER TABLE `cours`
  ADD PRIMARY KEY (`id_cours`);

--
-- Индексы таблицы `creneau`
--
ALTER TABLE `creneau`
  ADD PRIMARY KEY (`id_creneau`);

--
-- Индексы таблицы `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id_doc`);

--
-- Индексы таблицы `eval_exam`
--
ALTER TABLE `eval_exam`
  ADD PRIMARY KEY (`id_eval_exam`);

--
-- Индексы таблицы `eval_projet`
--
ALTER TABLE `eval_projet`
  ADD PRIMARY KEY (`id_eval_projet`);

--
-- Индексы таблицы `fastaccess`
--
ALTER TABLE `fastaccess`
  ADD PRIMARY KEY (`id_fast`);

--
-- Индексы таблицы `info_matiere`
--
ALTER TABLE `info_matiere`
  ADD PRIMARY KEY (`id_info`);

--
-- Индексы таблицы `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`id_mail`);

--
-- Индексы таблицы `materiel`
--
ALTER TABLE `materiel`
  ADD PRIMARY KEY (`id_materiel`);

--
-- Индексы таблицы `matiere`
--
ALTER TABLE `matiere`
  ADD PRIMARY KEY (`id_matiere`);

--
-- Индексы таблицы `note_exam`
--
ALTER TABLE `note_exam`
  ADD PRIMARY KEY (`id_note`);

--
-- Индексы таблицы `note_projet`
--
ALTER TABLE `note_projet`
  ADD PRIMARY KEY (`id_note_projet`);

--
-- Индексы таблицы `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id_notif`);

--
-- Индексы таблицы `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id_reservation`);

--
-- Индексы таблицы `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`);

--
-- Индексы таблицы `salle`
--
ALTER TABLE `salle`
  ADD PRIMARY KEY (`id_salle`);

--
-- Индексы таблицы `status_mail`
--
ALTER TABLE `status_mail`
  ADD PRIMARY KEY (`id_status`);

--
-- Индексы таблицы `todo_list`
--
ALTER TABLE `todo_list`
  ADD PRIMARY KEY (`id_todo_list`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `absence`
--
ALTER TABLE `absence`
  MODIFY `id_abs` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `actualite`
--
ALTER TABLE `actualite`
  MODIFY `id_actu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `cours`
--
ALTER TABLE `cours`
  MODIFY `id_cours` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `creneau`
--
ALTER TABLE `creneau`
  MODIFY `id_creneau` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `document`
--
ALTER TABLE `document`
  MODIFY `id_doc` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `eval_exam`
--
ALTER TABLE `eval_exam`
  MODIFY `id_eval_exam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `eval_projet`
--
ALTER TABLE `eval_projet`
  MODIFY `id_eval_projet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `fastaccess`
--
ALTER TABLE `fastaccess`
  MODIFY `id_fast` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `info_matiere`
--
ALTER TABLE `info_matiere`
  MODIFY `id_info` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `mail`
--
ALTER TABLE `mail`
  MODIFY `id_mail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `materiel`
--
ALTER TABLE `materiel`
  MODIFY `id_materiel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `matiere`
--
ALTER TABLE `matiere`
  MODIFY `id_matiere` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `note_exam`
--
ALTER TABLE `note_exam`
  MODIFY `id_note` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `note_projet`
--
ALTER TABLE `note_projet`
  MODIFY `id_note_projet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `notification`
--
ALTER TABLE `notification`
  MODIFY `id_notif` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id_reservation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `status_mail`
--
ALTER TABLE `status_mail`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `todo_list`
--
ALTER TABLE `todo_list`
  MODIFY `id_todo_list` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
